"""
Hybrid Parallel NLP System (Windows-Safe Final Version)
-------------------------------------------------------
• MPI (mpi4py) for distributed nodes
• ThreadPoolExecutor for intra-node parallelism
• Rank 0 → positive reviews
• Rank 1 → negative reviews
• Other ranks → both
• Works safely on Windows (no Unicode / MPI errors)
"""

from mpi4py import MPI
import pandas as pd
import string, re, os, sys
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
import nltk
from nltk.corpus import stopwords

# ---------- Fix Windows console encoding for UTF-8 ----------
sys.stdout.reconfigure(encoding='utf-8')

# ---------- Ensure script runs from its own directory ----------
os.chdir(os.path.dirname(__file__))

# ---------- NLTK setup ----------
nltk.download("stopwords", quiet=True)
STOP_WORDS = set(stopwords.words("english"))
TRANSLATOR = str.maketrans("", "", string.punctuation)

POS_KEYWORDS = {"good", "great", "excellent", "love", "best", "awesome", "wonderful", "perfect", "amazing"}
NEG_KEYWORDS = {"bad", "worst", "terrible", "awful", "hate", "poor", "boring", "disappointing"}


# ---------- Helper functions ----------
def clean_and_tokens(text):
    text = str(text).lower()
    text = re.sub(r"<.*?>", " ", text)
    text = text.translate(TRANSLATOR)
    tokens = text.split()
    return [w for w in tokens if w not in STOP_WORDS and w != "br" and w.strip()]


def label_sentiment(text, rating):
    """Return 'pos', 'neg', or None."""
    if rating is not None and not pd.isna(rating):
        try:
            r = float(rating)
            if r >= 4.0:
                return "pos"
            if r <= 2.0:
                return "neg"
        except Exception:
            pass

    txt = str(text).lower()
    pos_hits = any(k in txt for k in POS_KEYWORDS)
    neg_hits = any(k in txt for k in NEG_KEYWORDS)
    if pos_hits and not neg_hits:
        return "pos"
    if neg_hits and not pos_hits:
        return "neg"
    return None


def process_block(records, role):
    """Process subset of reviews and return sentiment word counters."""
    pos_ctr, neg_ctr = Counter(), Counter()
    for text, rating in records:
        sentiment = label_sentiment(text, rating)
        if role == "pos_only" and sentiment == "pos":
            pos_ctr.update(clean_and_tokens(text))
        elif role == "neg_only" and sentiment == "neg":
            neg_ctr.update(clean_and_tokens(text))
        elif role == "both":
            if sentiment == "pos":
                pos_ctr.update(clean_and_tokens(text))
            elif sentiment == "neg":
                neg_ctr.update(clean_and_tokens(text))
    return pos_ctr, neg_ctr


def chunkify(lst, n):
    """Split list into n roughly equal parts."""
    if n <= 0:
        return [lst]
    k, m = divmod(len(lst), n)
    return [lst[i * k + min(i, m):(i + 1) * k + min(i + 1, m)] for i in range(n)]


# ---------- Hybrid Pipeline ----------
def hybrid_pipeline_alt(dataset_path="review.csv", nrows=20000, threads_per_node=None, top_k=20):
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()

    # Choose thread count per node
    if threads_per_node is None:
        try:
            import multiprocessing as mp
            threads_per_node = max(1, min(32, mp.cpu_count()))
        except Exception:
            threads_per_node = 4

    global_start = MPI.Wtime()

    # ---------- Load + distribute ----------
    if rank == 0:
        if not os.path.exists(dataset_path):
            raise FileNotFoundError(
                f"Dataset '{dataset_path}' not found. Place it next to this script or set full path."
            )

        df = pd.read_csv(dataset_path, nrows=nrows)
        text_col = next((c for c in df.columns if "review" in c.lower() or "text" in c.lower()), None)
        rating_col = next((c for c in df.columns if "rate" in c.lower() or "rating" in c.lower() or "score" in c.lower()), None)

        if text_col is None:
            raise ValueError("No text/review column found in dataset!")

        if rating_col is not None:
            records = list(zip(df[text_col].astype(str).tolist(), df[rating_col].tolist()))
        else:
            records = list(zip(df[text_col].astype(str).tolist(), [None] * len(df)))

        chunks = chunkify(records, size)
        for i in range(1, size):
            comm.send(chunks[i], dest=i, tag=11)
        local_records = chunks[0]
    else:
        local_records = comm.recv(source=0, tag=11)

    # ---------- Assign sentiment role ----------
    role = "pos_only" if rank == 0 else ("neg_only" if rank == 1 else "both")

    # ---------- Local threaded processing ----------
    local_start = MPI.Wtime()
    pos_counter_local, neg_counter_local = Counter(), Counter()
    lines = len(local_records)

    if lines > 0:
        subchunks = chunkify(local_records, min(threads_per_node, lines))
        with ThreadPoolExecutor(max_workers=len(subchunks)) as pool:
            futures = [pool.submit(process_block, sc, role) for sc in subchunks]
            for fut in as_completed(futures):
                pc, nc = fut.result()
                pos_counter_local.update(pc)
                neg_counter_local.update(nc)

    local_time = MPI.Wtime() - local_start
    print(f"Node {rank} ({role}): processed {lines} reviews in {local_time:.2f}s", flush=True)

    # ---------- Gather results ----------
    payload = {
        "rank": rank,
        "role": role,
        "pos_counter": dict(pos_counter_local),
        "neg_counter": dict(neg_counter_local),
        "local_time": local_time,
        "lines": lines,
    }
    all_payloads = comm.gather(payload, root=0)

    # ---------- Master combines and prints ----------
    if rank == 0:
        total_pos, total_neg = Counter(), Counter()
        node_summaries = []
        for p in all_payloads:
            total_pos.update(Counter(p["pos_counter"]))
            total_neg.update(Counter(p["neg_counter"]))
            node_summaries.append((p["rank"], p["role"], p["lines"], p["local_time"]))

        global_end = MPI.Wtime()
        hybrid_total = global_end - global_start
        max_local = max((t for (_, _, _, t) in node_summaries), default=0)
        comm_overhead = max(0.0, hybrid_total - max_local)

        # ---------- Output ----------
        for r, rrole, lines, t in sorted(node_summaries, key=lambda x: x[0]):
            label = "positive" if rrole == "pos_only" else ("negative" if rrole == "neg_only" else "both")
            print(f"Node {r} ({label}): processed {lines} reviews in {t:.2f}s")

        print(f"Communication overhead: {comm_overhead:.2f}s")
        print(f"Hybrid total time: {hybrid_total:.2f}s")

        seq_time = 58.2  # Replace with your sequential runtime
        speedup = seq_time / hybrid_total if hybrid_total > 0 else 0.0
        print(f"Hybrid speedup: {speedup:.2f}x vs Sequential\n")

        print("=== Top Positive Words ===")
        for w, c in total_pos.most_common(top_k):
            print(f"{w} ({c})")

        print("\n=== Top Negative Words ===")
        for w, c in total_neg.most_common(top_k):
            print(f"{w} ({c})")


# ---------- Entry point ----------
if __name__ == "__main__":
    # Automatically looks for review.csv in same folder
    hybrid_pipeline_alt(dataset_path="review.csv", nrows=20000, threads_per_node=None, top_k=20)
