# ============================================================
# mpi_text_analysis.py  (Task 3 - Distributed Text Analysis)
# ============================================================

from mpi4py import MPI
import pandas as pd
import string, re
from collections import Counter
import nltk
from nltk.corpus import stopwords
nltk.download('stopwords', quiet=True)

# ------------------ Text Cleaning ------------------
stop_words = set(stopwords.words('english'))
translator = str.maketrans('', '', string.punctuation)

def clean_text(text):
    text = str(text).lower()
    text = re.sub(r'<.*?>', ' ', text)        # remove HTML tags
    text = text.translate(translator)         # remove punctuation
    tokens = text.split()
    return [w for w in tokens if w not in stop_words and w != 'br']

def local_count(text_list):
    local_counter = Counter()
    for line in text_list:
        local_counter.update(clean_text(line))
    return local_counter

# ------------------ MPI Setup ------------------
comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()

dataset_path = dataset_path = "F:\\Work\\University\\Semester 6\\PDC\\Sp23-bcs-123(Mids Lab)\\review.csv"
  # your dataset file
start_time = MPI.Wtime()

# ------------------ Master: Load + Distribute ------------------
if rank == 0:
    df = pd.read_csv(dataset_path, nrows=20000)
    text_col = next((c for c in df.columns if 'review' in c.lower() or 'text' in c.lower()), None)
    if text_col is None:
        raise ValueError("No text column found in dataset!")

    data = df[text_col].astype(str).tolist()

    # Evenly split dataset across ranks (round-robin style)
    chunks = [data[i::size] for i in range(size)]

    # Send chunks to workers
    for i in range(1, size):
        comm.send(chunks[i], dest=i, tag=11)
    local_data = chunks[0]
else:
    local_data = comm.recv(source=0, tag=11)

# ------------------ Local Processing ------------------
local_start = MPI.Wtime()
local_counter = local_count(local_data)
local_end = MPI.Wtime()
local_time = local_end - local_start
print(f"Rank {rank} processed {len(local_data)} lines in {local_time:.2f}s")

# ------------------ Gather Results ------------------
all_counters = comm.gather(local_counter, root=0)
end_time = MPI.Wtime()

# ------------------ Master: Combine + Report ------------------
if rank == 0:
    total_counter = Counter()
    for c in all_counters:
        total_counter.update(c)

    total_time = end_time - start_time
    top_20 = total_counter.most_common(20)
    pd.DataFrame(top_20, columns=['Word', 'Frequency']).to_csv('mpi_output.csv', index=False)

    # Replace with your measured sequential runtime
    seq_time = 58.2
    speedup = seq_time / total_time

    print("\n=== MPI Summary ===")
    print(f"Total distributed time: {total_time:.2f}s")
    print(f"Speedup over sequential: {speedup:.2f}x")
    print("Top 20 words:")
    for w, c in top_20:
        print(f"{w} ({c})")
