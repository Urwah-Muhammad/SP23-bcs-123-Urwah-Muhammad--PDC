const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const path = require('path');

const PROTO_PATH = path.join(__dirname, 'user.proto');
const packageDefinition = protoLoader.loadSync(PROTO_PATH);
const userProto = grpc.loadPackageDefinition(packageDefinition);

const dummyUser = { id: 1, name: "Student Name", email: "student@pdc.edu", bio: "a".repeat(1000) };

function getUser(call, callback) {
    // gRPC sends binary, extremely compact
    callback(null, dummyUser);
}

const server = new grpc.Server();
server.addService(userProto.UserService.service, { GetUser: getUser });

server.bindAsync('0.0.0.0:50051', grpc.ServerCredentials.createInsecure(), () => {
    console.log('gRPC Server running on port 50051');
    server.start();
});