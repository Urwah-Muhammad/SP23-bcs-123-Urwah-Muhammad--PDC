const express = require('express');
const app = express();
const port = 3000;

const dummyUser = { id: 1, name: "Student Name", email: "student@pdc.edu", bio: "a".repeat(1000) }; // Large payload for testing

app.get('/user', (req, res) => {
    res.json(dummyUser);
});

app.listen(port, () => {
    console.log(`REST Server running on port ${port}`);
});