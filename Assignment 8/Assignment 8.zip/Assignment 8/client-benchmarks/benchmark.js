const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const path = require('path');

async function benchmarkREST() {
    const start = performance.now();
    const res = await fetch('http://localhost:3000/user');
    const data = await res.json();
    const end = performance.now();
    
    // Estimate payload size (rough string length)
    const size = JSON.stringify(data).length;
    console.log(`REST: ${(end - start).toFixed(3)}ms | Payload: ~${size} bytes`);
}

async function benchmarkTRPC() {
    const start = performance.now();
    // tRPC uses a specific query format in URL
    const res = await fetch('http://localhost:3001/trpc/getUser'); 
    const data = await res.json();
    const end = performance.now();
    
    const size = JSON.stringify(data).length;
    console.log(`tRPC: ${(end - start).toFixed(3)}ms | Payload: ~${size} bytes`);
}

function benchmarkGRPC() {
    const PROTO_PATH = path.join(__dirname, '../grpc-server/user.proto');
    const packageDefinition = protoLoader.loadSync(PROTO_PATH);
    const userProto = grpc.loadPackageDefinition(packageDefinition);
    const client = new userProto.UserService('localhost:50051', grpc.credentials.createInsecure());

    const start = performance.now();
    client.GetUser({ id: "1" }, (err, response) => {
        const end = performance.now();
        // Note: Payload is binary in wire, but we see object here. 
        // gRPC is usually 30-50% smaller on the wire.
        console.log(`gRPC: ${(end - start).toFixed(3)}ms | Payload: Binary (Compact)`);
    });
}

(async () => {
    console.log("--- Starting Benchmarks ---");
    await benchmarkREST();
    await benchmarkTRPC();
    benchmarkGRPC();
})();