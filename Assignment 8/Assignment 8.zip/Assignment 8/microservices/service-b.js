const express = require('express');
const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const path = require('path');

// Setup gRPC Client inside Service B
const PROTO_PATH = path.join(__dirname, '../grpc-server/user.proto');
const packageDefinition = protoLoader.loadSync(PROTO_PATH);
const userProto = grpc.loadPackageDefinition(packageDefinition);
const client = new userProto.UserService('localhost:50051', grpc.credentials.createInsecure());

const app = express();

app.get('/gateway/user', (req, res) => {
    const start = performance.now();
    
    // Internal gRPC call to Service A
    client.GetUser({ id: "1" }, (err, response) => {
        if (err) res.status(500).send(err);
        
        const end = performance.now();
        console.log(`Internal gRPC Latency: ${(end - start).toFixed(3)}ms`);
        
        res.json(response);
    });
});

app.listen(4000, () => {
    console.log('Service B (Gateway) running on port 4000');
});