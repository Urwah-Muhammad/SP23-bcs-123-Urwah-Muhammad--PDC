const express = require('express');
const { initTRPC } = require('@trpc/server');
const { createExpressMiddleware } = require('@trpc/server/adapters/express');
const { z } = require('zod');

// 1. Initialize tRPC
const t = initTRPC.create();

// 2. Create the App and Router
const app = express();
const dummyUser = { 
    id: 1, 
    name: "Student Name", 
    email: "student@pdc.edu", 
    bio: "This is a long bio text used to increase the payload size for performance testing. ".repeat(50) 
};

const appRouter = t.router({
  // Define a procedure (endpoint) named 'getUser'
  getUser: t.procedure
    .output(z.object({ id: z.number(), name: z.string(), email: z.string(), bio: z.string() })) // Validation
    .query(() => {
      console.log("tRPC Request Received");
      return dummyUser;
    }),
});

// 3. Apply the tRPC middleware to Express
app.use('/trpc', createExpressMiddleware({ router: appRouter }));

app.listen(3001, () => {
  console.log('tRPC Server running on http://localhost:3001');
});